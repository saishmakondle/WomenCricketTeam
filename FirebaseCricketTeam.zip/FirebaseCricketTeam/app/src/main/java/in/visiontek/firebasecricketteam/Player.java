package in.visiontek.firebasecricketteam;

import android.widget.TextView;

import java.io.Serializable;

public class Player implements Serializable {
    String name,role;

    public Player() {

    }

    public Player(String name, String role) {
        this.name = name;
        this.role = role;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
