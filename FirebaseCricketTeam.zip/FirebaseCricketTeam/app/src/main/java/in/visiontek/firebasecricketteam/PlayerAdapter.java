package in.visiontek.firebasecricketteam;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class PlayerAdapter extends RecyclerView.Adapter<PlayerAdapter.MyViewHolder> {
    ArrayList<Player> playerArrayList;
    Context context;
    int currentPosition;
    DatabaseReference databaseReference;

    public PlayerAdapter(Context context, ArrayList<Player> playerArrayList) {
        this.context = context;
        this.playerArrayList = playerArrayList;

    }

    @NonNull
    @Override
    public PlayerAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.player_card, null);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PlayerAdapter.MyViewHolder holder, int position) {
        Player player = playerArrayList.get(position);
        holder.nameTv.setText(player.getName());
        holder.roleTv.setText(player.getRole());
        if (player.getRole().equals("Batting")) {
            holder.image.setImageResource(R.drawable.batting);
        }
        if (player.getRole().equals("Bowling")) {
            holder.image.setImageResource(R.drawable.bowling);
        }
        if (player.getRole().equals("All Rounder")) {
            holder.image.setImageResource(R.drawable.img);
        }
        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                PopupMenu popupMenu = new PopupMenu(context,v);
                currentPosition=holder.getAdapterPosition();
                popupMenu.getMenuInflater().inflate(R.menu.popup_menu, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        if (item.getItemId() == R.id.edit){
                            editPlayer();
                        }
                        else if (item.getItemId() == R.id.delete){
                            deletePlayer();
                        }
                        return true;
                    }
                });
                popupMenu.show();
                return true;
            }



        });

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(context,PlayerView.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("Players",player);
                v.getContext().startActivity(intent);
            }
        });
    }
    private void deletePlayer() {
        Player player = playerArrayList.get(currentPosition);
        databaseReference= FirebaseDatabase.getInstance().getReference("Players");
        Query query = databaseReference.orderByChild("name").equalTo(player.getName());
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshott: snapshot.getChildren()) {
                    dataSnapshott.getRef().removeValue();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void editPlayer() {

    }
    @Override
    public int getItemCount() {
        return playerArrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView nameTv,roleTv;
        ImageView image;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            image=itemView.findViewById(R.id.image_card);
            nameTv = itemView.findViewById(R.id.player_name_card);
            roleTv = itemView.findViewById(R.id.player_role_card);

        }
    }
}
