package in.visiontek.firebasecricketteam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class PlayerView extends AppCompatActivity {
TextView nameTv,roleTv;
ImageView playerImg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player_view);

        nameTv=findViewById(R.id.player_nameTv);
        roleTv=findViewById(R.id.player_roleTv);
        playerImg=findViewById(R.id.player_image);

        Intent in = getIntent();
        Player player = (Player) in.getSerializableExtra("Players");
        nameTv.setText(player.getName());
        roleTv.setText(player.getRole());
        if (player.getRole().equals("Batting")) {
            playerImg.setImageResource(R.drawable.batting);
        }
        if (player.getRole().equals("Bowling")) {
            playerImg.setImageResource(R.drawable.bowling);
        }
        if (player.getRole().equals("All Rounder")) {
            playerImg.setImageResource(R.drawable.img);
        }
    }
}