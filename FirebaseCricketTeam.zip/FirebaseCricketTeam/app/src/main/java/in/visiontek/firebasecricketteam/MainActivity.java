package in.visiontek.firebasecricketteam;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    Spinner nameSpinner, roleSpinner;
    Button addBtn;
    String name,role;
    RecyclerView recyclerView;
    ArrayList<Player> playerArrayList;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView=findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("Players");

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.add_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.add_icon) {
            Dialog dialog = new Dialog(this);
            dialog.setContentView(R.layout.activity_spinner);
            dialog.show();
            //dialog.setTitle("Add Player");

            nameSpinner = dialog.findViewById(R.id.name_spinner);
            ArrayAdapter<CharSequence> arrayAdapter = ArrayAdapter.createFromResource(getApplicationContext(), R.array.player_name, android.R.layout.simple_spinner_dropdown_item);
            nameSpinner.setAdapter(arrayAdapter);
            nameSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    name = parent.getItemAtPosition(position).toString();
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });


            roleSpinner = dialog.findViewById(R.id.role_spinner);
            ArrayAdapter<CharSequence> arrayAdapter1 = ArrayAdapter.createFromResource(getApplicationContext(), R.array.player_role, android.R.layout.simple_spinner_dropdown_item);
            roleSpinner.setAdapter(arrayAdapter1);
            roleSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    role = parent.getItemAtPosition(position).toString();
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
            addBtn = dialog.findViewById(R.id.add_btn);
            addBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    addDataToFireBase(name, role);
                    dialog.dismiss();
                    loadData();
                }

                private void loadData() {
                    databaseReference = FirebaseDatabase.getInstance().getReference("Players");
                    databaseReference.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            playerArrayList = new ArrayList<>();
                            for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                                Player player = dataSnapshot.getValue(Player.class);
                                playerArrayList.add(player);
                            }
                            PlayerAdapter playerAdapter = new PlayerAdapter(getApplicationContext(), playerArrayList);
                            recyclerView.setAdapter(playerAdapter);
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }

                private void addDataToFireBase(String name, String role) {
                    Player player = new Player(name, role);
                    databaseReference.push().setValue(player);
                }
            });
        }
        return super.onOptionsItemSelected(item);
    }


}